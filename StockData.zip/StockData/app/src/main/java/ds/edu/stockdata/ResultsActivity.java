package ds.edu.stockdata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.net.MalformedURLException;
import java.net.URL;

public class ResultsActivity extends AppCompatActivity {

    public static final String NAME = "NAME";
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        /**Intent intent = getIntent();
        name = intent.getStringExtra(NAME);
        TextView text = (TextView) findViewById(R.id.textView);
        if(name !=null){
            text.setText(name);
        }*/
        StockData stock = (StockData) getIntent().getSerializableExtra("STOCK_DATA",StockData.class);
        TextView text = (TextView) findViewById(R.id.textView);
        TextView text2 = (TextView) findViewById(R.id.editTextTextMultiLine);
        GraphView graph = (GraphView) findViewById(R.id.graph);
        //URL newsLink = new URL();

        if(stock !=null){
            text.setText("Company Name: " + stock.getName() +"\n"+ "Industry: " + stock.getIndustry()+"\n"+
                    "Exchange: " + stock.getExchange() +"\n"+ "Price: $" + stock.getPrice()+"\n"+ "Day Low: $" + stock.getDayLow()+"\n"
                    + "Day High: $" + stock.getDayHigh()+"\n"+ "Previous Close: $" + stock.getPreviousClose()+"\n");
            try {
                if(stock.getUrl()!= null && stock.getTitle()!= null){
                text2.setText(stock.getName() + " in the news: " + stock.getTitle() +"\n" +
                        "Read more " + new URL(stock.getUrl()));}
                else if(stock.getUrl()== null && stock.getTitle()== null){
                    text2.setVisibility(View.INVISIBLE);
                }
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            //https://www.youtube.com/watch?v=aslWfx2zT8A
            DataPoint[] dataPoints = new DataPoint[] {
                    new DataPoint(0, stock.getPreviousClose()),
                    //new DataPoint(0.5, stock.getDayLow()),
                    new DataPoint(0.5, stock.getPrice()),
                    //new DataPoint(1.5, stock.getDayHigh()),
            };

            LineGraphSeries <DataPoint> series = new LineGraphSeries<>(dataPoints);
            graph.addSeries(series);
            series.setDrawDataPoints(true);
            series.setDrawBackground(true);
            series.setTitle("Change in price of stock");


        }
        else {
            text.setText("No Stock Data found for search");
            text2.setVisibility(View.INVISIBLE);
            graph.setVisibility(View.INVISIBLE);


        }

        Button searchButton = (Button) findViewById(R.id.button);

        /*
         * Find the "submit" button, and add a listener to it
         */
        // Add a listener to the send button
        searchButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                Intent i = new Intent(ResultsActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }


}