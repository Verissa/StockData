package ds.edu.stockdata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    MainActivity me = this;
    ImageButton searchButton = null;
    TextView text = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final MainActivity ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */


 searchButton = (ImageButton) findViewById(R.id.search);
 text = (TextView) findViewById(R.id.textView3);


        // Add a listener to the send button
        searchButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                String searchTerm = ((EditText)findViewById(R.id.stock)).getText().toString();
                if(!searchTerm.matches(".*[^a-zA-Z0-9].*")) {
                    //text.setVisibility(View.INVISIBLE);
                    //System.out.println("correct data");
                    SearchStock gp = new SearchStock();
                    gp.search(searchTerm, me, ma); // Done asynchronously in another thread.
                } else if (searchTerm.matches(".*[^a-zA-Z0-9].*")) {
                    //System.out.println("incorrect data");
                    text.setVisibility(View.VISIBLE);
                    text.setText("Please enter a valid stock symbol, letters & numbers only");
                    //Intent newI = new Intent(me, MainActivity.class);
                    //startActivity(newI);
                }
            }
        });
    }

    //https://www.youtube.com/watch?v=tNmxq4OVq7E
    public void dataReady(StockData stock){
        if(stock != null) {
            Intent i = new Intent(me, ResultsActivity.class);
            i.putExtra("STOCK_DATA", stock);
            startActivity(i);
        }
   }

   public void serverDown(){
       runOnUiThread(new Runnable() {
           public void run() {
               text = (TextView) findViewById(R.id.textView3);
               text.setVisibility(View.VISIBLE);
               text.setText("Unable to reach server/ third-party API");
           }
       });
   }

   public void noData(){
       runOnUiThread(new Runnable() {
           public void run() {
               text = (TextView) findViewById(R.id.textView3);
               text.setVisibility(View.VISIBLE);
               text.setText("No stock data can be found");
           }
       });
   }


}