package ds.edu.stockdata;

import android.app.Activity;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.json.JSONException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


public class SearchStock {
    MainActivity ma = null;   // for callback
    String stockSymbol = null;       // search Web Service for data on stock
    StockData stockData = null;
    private static final String SEARCH_ENDPOINT = "https://verissa-cuddly-space-adventure-9qxp7pq9pj7f9vj6-8080.preview.app.github.dev/search";

    // search( )
    // Parameters:
    // String stockSymbol: the thing to search for on the web service
    // Activity activity: the UI thread activity
    //public void search(String stockSymbol, Activity activity, MainActivity ma) {
    public void search(String stockSymbol, Activity activity, MainActivity ma) {
        this.ma = ma;
        this.stockSymbol = stockSymbol;
        new BackgroundTask(activity).execute();
    }

    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    try {
                        doInBackground();
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() throws JSONException, IOException {
            stockData = search(stockSymbol);
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() {
            ma.dataReady(stockData);
        }


        private StockData search(String searchTerm) throws IOException, JSONException {
            // Make an HTTP request to the web service with the search term as a query parameter
            String urlWithParams = SEARCH_ENDPOINT + "?searchTerm=" + URLEncoder.encode(searchTerm, "UTF-8");
            URL url = new URL(urlWithParams);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            // Getting response code
            int responseCode = connection.getResponseCode();

            // If responseCode is 200 means we get data successfully
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder jsonResponseData = new StringBuilder();
                String readLine = null;

                // Append response line by line
                while ((readLine = in.readLine()) != null) {
                    jsonResponseData.append(readLine);
                }

                in.close();
                //JsonObject marketauxJsonObject = new Gson().fromJson(marketauxJsonResponseData.toString(), JsonObject.class);
//System.out.println(jsonResponseData.toString() + responseCode);
                if(jsonResponseData!= null && !jsonResponseData.toString().contains("down")){
                // Parse the JSON response data and extract the information you need
                JsonObject jsonObject = new Gson().fromJson(jsonResponseData.toString(), JsonObject.class);
                //JSONObject quoteObject = jsonObject.getJSONObject("quote");

                String name = jsonObject.get("name").getAsString();
                JsonElement industryElement = jsonObject.get("industry");
                String industry = null;
                if(industryElement.toString().contains("null")){ industry = null;
                    //System.out.println("hi " + jsonObject.toString());
                }
                //System.out.println("hi " + jsonObject.toString());
                if(!industryElement.toString().contains("null")){
                    //System.out.println("no " + jsonObject.toString());
                    industry = jsonObject.get("industry").getAsString();
                    }
                JsonElement exElement = jsonObject.get("industry");
                String exchange = null;
                if(exElement.toString().contains("null")){ exchange = null;}
                if(!exElement.toString().contains("null")){ exchange = jsonObject.get("exchange").getAsString();}
                JsonElement titleElement = jsonObject.get("industry");
                String title = null;
                if(titleElement.toString().contains("null")){ title = null;}
                if(!titleElement.toString().contains("null")){ title = jsonObject.get("title").getAsString();}
                JsonElement urlElement = jsonObject.get("industry");
                String newsUrl = null;
                if(urlElement.toString().contains("null")){ newsUrl = null;}
                if(!urlElement.toString().contains("null")){ newsUrl = jsonObject.get("url").getAsString();}
                float price = jsonObject.get("price").getAsFloat();
                float dayLow = jsonObject.get("dayLow").getAsFloat();
                float dayHigh = jsonObject.get("dayHigh").getAsFloat();
                float previousClose = jsonObject.get("previousClose").getAsFloat();

                // Create a new StockData object with the extracted data
                StockData stockData = new StockData(name, industry, exchange, price, dayLow, dayHigh, previousClose, title, newsUrl);
                return stockData;}
                else {
                    ma.noData();
                    return null;
                }

            } else if (responseCode == HttpURLConnection.HTTP_UNAVAILABLE) {
                //System.out.println("error");
                ma.serverDown();
                return null;
            } else {
                ma.serverDown();
                return null;
            }

        }
    }
}

