package ds.edu.stockdata;

import java.io.Serializable;

public class StockData implements Serializable {
    private String name;
    private String industry;
    private String exchange;
    private String title;
    private String url;
    private float price;
    private float dayLow;
    private float dayHigh;
    private float previousClose;

    public StockData(){}
    public StockData(String name, String industry,String exchange,float price,
                     float dayLow,float dayHigh, float previousClose, String title, String url){
        this.name = name;
        this.industry = industry;
        this.exchange = exchange;
        this.price = price;
        this.dayLow = dayLow;
        this.dayHigh = dayHigh;
        this.previousClose = previousClose;
        this.title = title;
        this.url = url;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getDayLow() {
        return dayLow;
    }

    public void setDayLow(float dayLow) {
        this.dayLow = dayLow;
    }

    public float getDayHigh() {
        return dayHigh;
    }

    public void setDayHigh(float dayHigh) {
        this.dayHigh = dayHigh;
    }

    public float getPreviousClose() {
        return previousClose;
    }

    public void setPreviousClose(float previousClose) {
        this.previousClose = previousClose;
    }
}
