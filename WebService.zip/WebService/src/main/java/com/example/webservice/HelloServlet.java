    //Name: Verissa Owusu ID:vowusu
    //Last modified: 9th April 2023
    //This is a web servlet that handles requests through the/search and /dashboard endpoints. The search searches 2
    //3rd party APIs and returns data to the client and then makes inserts into a database with records about the request
    //Aletheia API get name,day high, day low, previousclose and price for graph
    //MarketAux API get industry, exchange,  the latest news article which is at index 0 of data and get the title and the url
    //The /dashboard endpoint queries the database and presents some analytics to the user
    package com.example.webservice;

    import java.io.BufferedReader;
    import java.io.IOException;
    import java.io.InputStreamReader;
    import java.io.PrintWriter;
    import java.net.HttpURLConnection;
    import java.net.URL;
    import java.text.SimpleDateFormat;
    import java.util.*;
    import com.google.gson.Gson;
    import com.google.gson.JsonArray;
    import com.google.gson.JsonElement;
    import com.google.gson.JsonObject;
    import jakarta.servlet.ServletException;
    import jakarta.servlet.http.HttpServlet;
    import jakarta.servlet.http.HttpServletRequest;
    import jakarta.servlet.http.HttpServletResponse;
    import jakarta.servlet.annotation.WebServlet;
    import com.mongodb.client.*;
    import com.mongodb.client.result.InsertOneResult;
    import org.bson.Document;
    import org.bson.types.ObjectId;

    @WebServlet(value = {"/search", "/dashboard"})
    public class HelloServlet extends HttpServlet {
        private static final String ALETHEIA_API_URL = "https://api.aletheiaapi.com/StockData?key=861059982CAA432CA72C26FFB3534D77&symbol=";
        private static final String MARKETAUX_API_URL = "https://api.marketaux.com/v1/news/all?api_token=8X0YkfefOOEQ9n5sA2ySwXcblvWU8JECO2O61aXN&filter_entities=true&language=en&symbols=";
        private static final String MONGODB_URI = "mongodb://Verrisa:eqR6KNP2LjNqtchV@ac-pxgawxe-shard-00-00.vjicotq.mongodb.net:27017,ac-pxgawxe-shard-00-01.vjicotq.mongodb.net:27017,ac-pxgawxe-shard-00-02.vjicotq.mongodb.net:27017/myFirstDatabase?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String path = request.getServletPath();
            // Retrieve the search term from the HTTP request
            if(path.contains("/search")) {
                String searchTerm = request.getParameter("searchTerm");
                response.setContentType("application/json");
                String userAgent = request.getHeader("User-Agent").split("\\(", 2)[0];
                //System.out.println("Device" + userAgent);
                Date currentDate = new Date();

                // Format the date and time as a string
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                String currentDateTime = dateFormat.format(currentDate);
                //System.out.println(currentDateTime);
                // Make an HTTP request to the Aletheia API with the search term as a query parameter
                URL aletheiaApiUrl = new URL(ALETHEIA_API_URL + searchTerm);
                HttpURLConnection aletheiaConnection = (HttpURLConnection) aletheiaApiUrl.openConnection();
                aletheiaConnection.setRequestProperty("Accept-Version", "2");
                aletheiaConnection.setRequestMethod("GET");

                // Getting response code
                int aletheiaResponseCode = aletheiaConnection.getResponseCode();

                if (aletheiaResponseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader aletheiaIn = new BufferedReader(new InputStreamReader(aletheiaConnection.getInputStream()));
                    StringBuffer aletheiaJsonResponseData = new StringBuffer();
                    String aletheiaReadLine;

                    while ((aletheiaReadLine = aletheiaIn.readLine()) != null) {
                        aletheiaJsonResponseData.append(aletheiaReadLine);
                    }

                    aletheiaIn.close();

                    // Create JSON object from the Aletheia API response data
                    JsonObject aletheiaJsonObject = new Gson().fromJson(aletheiaJsonResponseData.toString(), JsonObject.class);

                    // Make an HTTP request to the MarketAux API with the search term as a query parameter
                    URL marketauxApiUrl = new URL(MARKETAUX_API_URL + searchTerm);
                    HttpURLConnection marketauxConnection = (HttpURLConnection) marketauxApiUrl.openConnection();
                    marketauxConnection.setRequestMethod("GET");

                    // Getting response code
                    int marketauxResponseCode = marketauxConnection.getResponseCode();

                    if (marketauxResponseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader marketauxIn = new BufferedReader(new InputStreamReader(marketauxConnection.getInputStream()));
                        StringBuffer marketauxJsonResponseData = new StringBuffer();
                        String marketauxReadLine;

                        while ((marketauxReadLine = marketauxIn.readLine()) != null) {
                            marketauxJsonResponseData.append(marketauxReadLine);
                        }

                        marketauxIn.close();

                        // Create JSON object from the MarketAux API response data
                        JsonObject marketauxJsonObject = new Gson().fromJson(marketauxJsonResponseData.toString(), JsonObject.class);

                        // Extract data from the Aletheia API JSON response
                        String shortName = aletheiaJsonObject.get("ShortName").getAsString();
                        float dayHigh = aletheiaJsonObject.get("DayHigh").getAsFloat();
                        float dayLow = aletheiaJsonObject.get("DayLow").getAsFloat();
                        JsonElement f = aletheiaJsonObject.get("PreviousClose");
                        float previousClose = 0;
                        if(f != null){ previousClose = aletheiaJsonObject.get("PreviousClose").getAsFloat();}
                        if(f == null){ previousClose = aletheiaJsonObject.get("Open").getAsFloat();}
                        float price = aletheiaJsonObject.get("Price").getAsFloat();


                        String title = null,url = null,exchange = null, industry = null;

                        // Extract data from the Marketaux API JSON response
                        JsonArray data = (JsonArray) marketauxJsonObject.get("data");
                        if(data.size()>0) {
                            JsonObject firstItem = data.get(0).getAsJsonObject();
                             title = firstItem.get("title").getAsString();
                             url = firstItem.get("url").getAsString();
                            JsonArray data2 = firstItem.get("entities").getAsJsonArray();
                            JsonObject data21 = data2.get(0).getAsJsonObject();
                             exchange = data21.get("exchange").getAsString();
                             industry = data21.get("industry").getAsString();
                        }
                        else if (data.size() ==0) {
                            //JsonObject firstItem = data.get(0).getAsJsonObject();
                             title = null;
                             url = null;
                            //JsonArray data2 = firstItem.get("entities").getAsJsonArray();
                            //JsonObject data21 = data2.get(0).getAsJsonObject();
                            JsonElement e = aletheiaJsonObject.get("Exchange");
                             exchange = null;
                            if(e != null){ exchange = aletheiaJsonObject.get("Exchange").getAsString();}
                            if(e == null){ exchange = null;}
                             industry = null;

                        }

                        // Create a new JsonObject to store all the extracted data
                        JsonObject jsonResponse = new JsonObject();

                        // Add all the extracted data as properties to the JsonObject
                        jsonResponse.addProperty("name", shortName);
                        jsonResponse.addProperty("dayHigh", dayHigh);
                        jsonResponse.addProperty("dayLow", dayLow);
                        jsonResponse.addProperty("previousClose", previousClose);
                        jsonResponse.addProperty("price", price);
                        jsonResponse.addProperty("title", title);
                        jsonResponse.addProperty("url", url);
                        jsonResponse.addProperty("exchange", exchange);
                        jsonResponse.addProperty("industry", industry);

                        // Use PrintWriter object to write the JsonObject as a response to the client
                        PrintWriter out = response.getWriter();
                        out.print(jsonResponse.toString());
                        out.flush();

                        try (MongoClient mongoClient = MongoClients.create(MONGODB_URI)) {
                            MongoDatabase database = mongoClient.getDatabase("Aletheia");
                            MongoCollection<Document> collection = database.getCollection("StockData");
                            MongoCollection<Document> collection2 = database.getCollection("Requests");
                            if(jsonResponse == null) {
                                InsertOneResult result1 = collection2.insertOne(new Document()
                                        .append("_id", new ObjectId())
                                        .append("device", userAgent).append("date", currentDateTime).append("symbolTicker", searchTerm)
                                        .append("status", "failed").append("companyInfo",shortName + " " + industry).append("httpResponseCode", "503"));
                                System.out.println("error");
                            }
                            else if(jsonResponse != null) {
                                InsertOneResult result1 = collection2.insertOne(new Document()
                                        .append("_id", new ObjectId())
                                        .append("device", userAgent).append("date", currentDateTime).append("symbolTicker", searchTerm)
                                        .append("status", "success").append("companyInfo",shortName + " " + industry).append("httpResponseCode", "200"));
                            }
                            InsertOneResult result = collection.insertOne(new Document()
                                    .append("_id", new ObjectId())
                                    .append("name", shortName).append("industry", industry).append("exchange", exchange)
                                    .append("price", price).append("dayHigh", dayHigh).append("dayLow", dayLow)
                                    .append("previousClose", previousClose).append("title", title).append("url", url));


                        }
                    } else if (marketauxResponseCode != HttpURLConnection.HTTP_OK) {
                        try (MongoClient mongoClient = MongoClients.create(MONGODB_URI)) {
                            MongoDatabase database = mongoClient.getDatabase("Aletheia");
                            MongoCollection<Document> collection = database.getCollection("StockData");
                            MongoCollection<Document> collection2 = database.getCollection("Requests");
                                InsertOneResult result1 = collection2.insertOne(new Document()
                                        .append("_id", new ObjectId())
                                        .append("device", userAgent).append("date", currentDateTime).append("symbolTicker", searchTerm)
                                        .append("status", "failed").append("companyInfo"," " ).append("httpResponseCode", "500"));
                            }
                        PrintWriter out = response.getWriter();
                        out.print("MarketAux API is down");
                        out.flush();
                    }
                } else if (aletheiaResponseCode != HttpURLConnection.HTTP_OK) {
                    try (MongoClient mongoClient = MongoClients.create(MONGODB_URI)) {
                        MongoDatabase database = mongoClient.getDatabase("Aletheia");
                        MongoCollection<Document> collection = database.getCollection("StockData");
                        MongoCollection<Document> collection2 = database.getCollection("Requests");
                        InsertOneResult result1 = collection2.insertOne(new Document()
                                .append("_id", new ObjectId())
                                .append("device", userAgent).append("date", currentDateTime).append("symbolTicker", searchTerm)
                                .append("status", "failed").append("companyInfo"," " ).append("httpResponseCode", "500"));
                    }
                    PrintWriter out = response.getWriter();
                    out.print("Aletheia API is down");

                    out.flush();
                }
            } else if (path.contains("/dashboard")) {
                try (MongoClient mongoClient = MongoClients.create(MONGODB_URI)) {
                    MongoDatabase database = mongoClient.getDatabase("Aletheia");
                    MongoCollection<Document> collection = database.getCollection("StockData");
                    MongoCollection<Document> collection2 = database.getCollection("Requests");
                    FindIterable<Document> iterDoc = collection2.find();
                    Iterator it = iterDoc.iterator();

                    // Generate an HTML table to display the documents
                    StringBuilder sb = new StringBuilder();
                    sb.append("<html><head><title>Stock Data App Dashboard</title></head><body><table>");
                    sb.append("<table style=\"border-collapse: collapse;\">");
                    sb.append("<thead style=\"background-color: #D1F0FA;\">");
                    sb.append("<h2>Web Service Request Logs");
                    sb.append("</h2>");
                    sb.append("<tr><th style=\"border: 1px solid black;\">Device</th>" +
                            "<th style=\"border: 1px solid black;\">Date</th>" +
                            "<th style=\"border: 1px solid black;\">Symbol Ticker</th>"+
                            "<th style=\"border: 1px solid black;\">Status</th>" +
                            "<th style=\"border: 1px solid black;\">Response Code</th>"+
                            "<th style=\"border: 1px solid black;\">Company Info</th></tr>");
                    sb.append("</thead>");
                    sb.append("<tbody>");

                    while (it.hasNext()) {
                        Document doc = (Document) it.next();
                        String device = doc.getString("device");
                        String date = doc.getString("date");
                        String symbolTicker = doc.getString("symbolTicker");
                        String status = doc.getString("status");
                        String responseCode = doc.getString("httpResponseCode");
                        String companyInfo = doc.getString("companyInfo");
                        sb.append("<tr><td style=\"border: 1px solid black;\">").append(device)
                                .append("</td><td style=\"border: 1px solid black;\">").append(date)
                                .append("</td><td style=\"border: 1px solid black;\">").append(symbolTicker)
                                .append("</td><td style=\"border: 1px solid black;\">").append(status)
                                .append("</td><td style=\"border: 1px solid black;\">").append(responseCode)
                                .append("</td><td style=\"border: 1px solid black;\">").append(companyInfo)
                                .append("</td></tr>");
                    }

                    sb.append("</tbody>");
                    sb.append("</table></body></html>");

                    // Write the HTML table to the response output stream
                    //response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.println(sb.toString());

                    // MongoDB Aggregation pipeline to group by industry and count the number of documents in each group
                    //https://studio3t.com/knowledge-base/articles/mongodb-aggregation-framework/
                    List<Document> pipeline = Arrays.asList(
                            new Document("$group", new Document("_id", "$industry").append("count", new Document("$sum", 1))),
                            new Document("$sort", new Document("count", -1))
                    );

                    List<Document> results = collection.aggregate(pipeline).into(new ArrayList<>());

                    // Prepare the data for the bar chart
                    List<String> labels = new ArrayList<>();
                    List<Integer> counts = new ArrayList<>();
                    for (Document doc : results) {
                        labels.add("'"+ doc.getString("_id")+"'");
                        counts.add(doc.getInteger("count"));
                    }

                    // Generate the HTML and JavaScript for the bar chart using Chart.js library
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("<html><head><title>Stock Data App Dashboard</title>");
                    sb2.append("<h2>Stock Data Requests per Industry");
                    sb2.append("</h2>");
                    sb2.append("<script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>");
                    sb2.append("</head><body>");
                    sb2.append("<canvas id=\"myChart\"></canvas>");
                    sb2.append("<script>");
                    sb2.append("var ctx = document.getElementById('myChart').getContext('2d');");
                    sb2.append("var myChart = new Chart(ctx, {");
                    sb2.append("type: 'bar',");
                    sb2.append("data: {");
                    sb2.append("labels: ").append(labels).append(",");
                    sb2.append("datasets: [{");
                    sb2.append("label: 'Number of Records by Industry',");
                    sb2.append("data: ").append(counts).append(",");
                    sb2.append("backgroundColor: 'rgba(54, 162, 235, 0.2)',");
                    sb2.append("borderColor: 'rgba(54, 162, 235, 1)',");
                    sb2.append("borderWidth: 1");
                    sb2.append("}]");
                    sb2.append("},");
                    sb2.append("options: {");
                    sb2.append("scales: {");
                    sb2.append("y: {");
                    sb2.append("beginAtZero: true");
                    sb2.append("}");
                    sb2.append("}");
                    sb2.append("}");
                    sb2.append("});");
                    sb2.append("</script>");
                    sb2.append("</body></html>");

                    // Write the HTML and JavaScript to the response output stream
                    response.setContentType("text/html");
                    //PrintWriter out = response.getWriter();
                    out.println(sb2.toString());

                    List<Document> pipeline2 = new ArrayList<>();
                    pipeline2.add(new Document("$group", new Document("_id", "$name")
                            .append("name", new Document("$first", "$name"))
                            .append("industry", new Document("$first", "$industry"))
                            .append("exchange", new Document("$first", "$exchange"))
                            .append("price", new Document("$max", "$price"))));
                    pipeline2.add(new Document("$sort", new Document("price", -1)));
                    pipeline2.add(new Document("$limit", 3));

                    AggregateIterable<Document> iterDoc2 = collection.aggregate(pipeline2);

                    Iterator it2 = iterDoc2.iterator();

                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("<html><head><title>Stock Data App Dashboard</title></head><body><table>");
                    sb3.append("<table style=\"border-collapse: collapse;\">");
                    sb3.append("<thead style=\"background-color: #D1F0FA;\">");
                    sb3.append("<h2>Top 3 Highest Stocks");
                    sb3.append("</h2>");
                    sb3.append("<tr>" +
                            "<th style=\"border: 1px solid black;\">Name</th>" +
                            "<th style=\"border: 1px solid black;\">Industry</th>" +
                            "<th style=\"border: 1px solid black;\">Exchange</th>" +
                            "<th style=\"border: 1px solid black;\">Price</th></tr>");
                    sb3.append("</thead>");
                    sb3.append("<tbody>");

                    while (it2.hasNext()) {
                        Document doc = (Document) it2.next();
                        String name = doc.getString("name");
                        String industry = doc.getString("industry");
                        String exchange = doc.getString("exchange");
                        Double price = doc.getDouble("price");
                        sb3.append("<tr><td style=\"border: 1px solid black;\">").append(name).
                                append("</td><td style=\"border: 1px solid black;\">").
                                append(industry).append("</td><td style=\"border: 1px solid black;\">")
                                .append(exchange).append("</td><td style=\"border: 1px solid black;\">")
                                .append(price).append("</td></tr>");
                    }

                    sb3.append("</tbody>");
                    sb3.append("</table></body></html>");

                    // Write the HTML table to the response output stream
                    response.setContentType("text/html");
                    out.println(sb3.toString());

                    List<Document> pipeline3 = new ArrayList<>();
                    pipeline3.add(new Document("$group", new Document("_id", "$name")
                            .append("name", new Document("$first", "$name"))
                            .append("industry", new Document("$first", "$industry"))
                            .append("exchange", new Document("$first", "$exchange"))
                            .append("price", new Document("$min", "$price"))));
                    pipeline3.add(new Document("$sort", new Document("price", 1)));
                    pipeline3.add(new Document("$limit", 3));

                    AggregateIterable<Document> iterDoc3 = collection.aggregate(pipeline3);

                    //FindIterable<Document> iterDoc2 = collection.find().sort(new BasicDBObject("price", -1)).limit(3);
                    Iterator it3 = iterDoc3.iterator();

                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("<html><head><title>Stock Data App Dashboard</title></head><body><table>");
                    sb4.append("<table style=\"border-collapse: collapse;\">");
                    sb4.append("<thead style=\"background-color: #D1F0FA;\">");
                    sb4.append("<h2>Top 3 Lowest Priced Stocks");
                    sb4.append("</h2>");
                    sb4.append("<tr>" +
                            "<th style=\"border: 1px solid black;\">Name</th>" +
                            "<th style=\"border: 1px solid black;\">Industry</th>" +
                            "<th style=\"border: 1px solid black;\">Exchange</th>" +
                            "<th style=\"border: 1px solid black;\">Price</th></tr>");
                    sb4.append("</thead>");
                    sb4.append("<tbody>");

                    while (it3.hasNext()) {
                        Document doc = (Document) it3.next();
                        String name = doc.getString("name");
                        String industry = doc.getString("industry");
                        String exchange = doc.getString("exchange");
                        Double price = doc.getDouble("price");
                        sb4.append("<tr><td style=\"border: 1px solid black;\">").append(name).
                                append("</td><td style=\"border: 1px solid black;\">").
                                append(industry).append("</td><td style=\"border: 1px solid black;\">")
                                .append(exchange).append("</td><td style=\"border: 1px solid black;\">")
                                .append(price).append("</td></tr>");
                    }

                    sb4.append("</tbody>");
                    sb4.append("</table></body></html>");

                    // Write the HTML table to the response output stream
                    response.setContentType("text/html");
                    out.println(sb4.toString());
                    out.flush();
                }

            }
        }


        public void destroy() {
        }
    }